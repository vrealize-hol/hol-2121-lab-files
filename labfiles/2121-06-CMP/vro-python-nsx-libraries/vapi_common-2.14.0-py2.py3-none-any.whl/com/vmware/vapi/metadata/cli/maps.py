"""
Metadata service utilities
Shared CLI Maps instance
"""

__author__ = 'VMware, Inc.'
__copyright__ = 'Copyright 2018 VMware, Inc.  All rights reserved. -- VMware Confidential'  # pylint: disable=line-too-long


from com.vmware.vapi.metadata.util.maps import get_cli_maps

_cli_maps = get_cli_maps()


def get_shared_cli_maps():
    """
    Returns the shared CLI maps instance

    :rtype: :class:`com.vmware.vapi.metadata.util.CliMaps`
    :return: Cli maps
    """
    return _cli_maps

"""
Metadata service utilities
"""

__author__ = 'VMware, Inc.'
__copyright__ = 'Copyright 2012-2014, 2018 VMware, Inc.  All rights reserved. -- VMware Confidential'  # pylint: disable=line-too-long

import six

from vmware.vapi.lib.fingerprint import generate_fingerprint

# TODO: Make all these maps synchronized


class MetadataMaps(object):  # pylint: disable=R0902
    """
    Metadata maps class, containing metadata and details of metadata sources

    :type checksum: :class:`str`
    :ivar checksum: Checksum of the entire metadata

    :type sources: :class:`dict` of :class:`str`,
                   :class:`com.vmware.vapi.metadata.identifier.sources.SourceInfo`
    :ivar sources: Map of SourceId to SourceInfo

    :type source_checksums: :class:`dict` of :class:`str`, :class:`str`
    :ivar source_checksums: Map of SourceId to checksums

    :type product_checksums: :class:`dict` or :class:`str`, :class:`str`
    :ivar product_checksums: Map of ProductName to checksum

    :type product_info: :class:`dict` of :class:`str`,
        :class:`com.vmware.vapi.metadata.identifier.types.ProductInfo`
    :ivar product_info: Map of product name to ProductInfo

    :type package_info: :class:`dict` of :class:`str`,
        :class:`com.vmware.vapi.metadata.identifier.types.PackageInfo`
    :ivar package_info: Map of package name to PackageInfo

    :type service_info: :class:`dict` of :class:`str`,
        :class:`com.vmware.vapi.metadata.identifier.types.ServiceInfo`
    :ivar service_info: Map of service name to ServiceInfo

    :type structure_info: :class:`dict` of :class:`str`,
        :class:`com.vmware.vapi.metadata.identifier.types.StructureInfo`
    :ivar structure_info: Map of structure name to StructureInfo

    :type operation_info: :class:`dict` of :class:`str`,
        :class:`com.vmware.vapi.metadata.identifier.types.MethodInfo`
    :ivar operation_info: Map of operation name to MethodInfo

    :type product_mapping: :class:`dict` of :class:`str`, :class:`list` of :class:`str`
    :ivar product_mapping: Map of SourceId to Product name

    :type package_mapping: :class:`dict` of :class:`str`, :class:`list` of :class:`str`
    :ivar package_mapping: Map of SourceId to Package name

    :type service_mapping: :class:`dict` of :class:`str`, :class:`list` of :class:`str`
    :ivar service_mapping: Map of SourceId to Service name

    :type structure_mapping: :class:`dict` of :class:`str`, :class:`list` of :class:`str`
    :ivar structure_mapping: Map of SourceId to Structure name

    :type operation_mapping: :class:`dict` of :class:`str`, :class:`list` of :class:`str`
    :ivar operation_mapping: Map of SourceId to Method identity
    """
    def __init__(self):
        # Checksum of all the metadata on the server
        self.checksum = None
        self.fingerprint = None

        # Set of sources (file/remote)
        self.sources = {}

        # These 2 maps are used to pre-compute
        # the checksums
        self.source_checksums = {}
        self.source_fingerprints = {}
        self.product_checksums = {}
        self.component_fingerprints = {}

        # These 5 maps are used to keep track of id's
        # with their corresponding info objects
        self.component_info = {}
        self.product_info = {}
        self.package_info = {}
        self.service_info = {}
        self.structure_info = {}
        self.operation_info = {}

        # These 5 maps are used to add/delete the appropriate
        # keys in the info maps when a particular source
        # is added/deleted
        self.component_mapping = {}
        self.product_mapping = {}
        self.package_mapping = {}
        self.service_mapping = {}
        self.structure_mapping = {}
        self.operation_mapping = {}

    def update_checksum(self):
        """
        Update checksum for vAPI service metadata
        """
        data = self.product_info.__repr__()
        self.checksum = generate_fingerprint(data)

    def update_fingerprint(self):
        """
        Update fingerprint for vAPI service metadata
        """
        data = self.component_info.__repr__()
        self.fingerprint = generate_fingerprint(data)

    def remove(self, id_):
        """
        Remove metadata for a vAPI service

        :type  id_: :class:`str`
        :kwarg id_: Metadata source id
        """

        if id_ not in self.sources:
            return
        del self.sources[id_]

        if id_ in self.source_checksums:
            del self.source_checksums[id_]

        if id_ in self.product_mapping:
            for product_id in self.product_mapping[id_]:
                del self.product_info[product_id]
                del self.product_checksums[product_id]
            del self.product_mapping[id_]

        if id_ in self.component_mapping:
            for component_id in self.component_mapping[id_]:
                del self.component_info[component_id]
                del self.component_fingerprints[component_id]
            del self.component_mapping[id_]

        if id_ in self.package_mapping:
            for package_id in self.package_mapping[id_]:
                del self.package_info[package_id]
            del self.package_mapping[id_]

        if id_ in self.service_mapping:
            for service_id in self.service_mapping[id_]:
                del self.service_info[service_id]
            del self.service_mapping[id_]

        if id_ in self.structure_mapping:
            for structure_id in self.structure_mapping[id_]:
                del self.structure_info[structure_id]
            del self.structure_mapping[id_]

        if id_ in self.operation_mapping:
            for operation_id in self.operation_mapping[id_]:
                del self.operation_info[operation_id]
            del self.operation_mapping[id_]


class MetaModelMaps(MetadataMaps):
    """
    Metamodel maps

    :type enumeration_info: :class:`dict` of :class:`str`,
        :class:`com.vmware.vapi.metadata.identifier.types.EnumerationInfo`
    :ivar enumeration_info: Map of Enumeration name to EnumerationInfo
    :type enumeration_mapping: :class:`dict` of :class:`str`, :class:`list` of :class:`str`
    :ivar enumeration_mapping: Map of SourceId to Enumeration name
    :type resource_mapping: :class:`dict` of :class:`str`. :class:`list` of :class:`str`
    :ivar resource_mapping: Map of source id to resource types
    :type model_info: :class:`dict` of :class:`str`, :class:`set`
    :ivar model_info: Stores set of models for a given resource type
    """
    def __init__(self):
        # *_mapping dictionaries are created so that when the source
        # is remove, the corresponding data contributed by that source
        # is removed
        self.enumeration_info = {}
        self.enumeration_mapping = {}
        self.resource_mapping = {}
        self.model_info = {}
        MetadataMaps.__init__(self)

    def remove(self, id_):
        """
        Remove metadata for a vAPI source

        :type  id_: :class:`str`
        :param id_: Metadata source id
        """
        if id_ in self.enumeration_mapping:
            for enumeration_id in self.enumeration_mapping[id_]:
                del self.enumeration_info[enumeration_id]
            del self.enumeration_mapping[id_]

        model_keys_to_delete = []
        if id_ in self.structure_mapping:
            for structure_id in self.structure_mapping[id_]:
                for k, v in self.model_info.items():
                    if structure_id in v:
                        v.remove(structure_id)
                    if len(v) == 0:
                        model_keys_to_delete.append(k)
        for k in model_keys_to_delete:
            if k in self.model_info:
                del self.model_info[k]

        if id_ in self.resource_mapping:
            del self.resource_mapping[id_]
        MetadataMaps.remove(self, id_)


class PrivilegeMaps(MetadataMaps):
    """
    Privilege maps
    """
    def __init__(self):
        MetadataMaps.__init__(self)


class RoutingMaps(MetadataMaps):
    """
    Routing maps
    """
    def __init__(self):
        MetadataMaps.__init__(self)


class AuthenticationMaps(MetadataMaps):
    """
    Authentication maps
    """
    def __init__(self):
        MetadataMaps.__init__(self)


class CliMaps(object):
    """
    CLI Metadata maps class.

    :type fingerprint: :class:`str`
    :ivar fingerprint: Fingerprint of the entire metadata

    :type sources: :class:`dict` of :class:`str`,
                   :class:`com.vmware.vapi.metadata.cli.source.Info`
    :ivar sources: Map of SourceId to SourceInfo

    :type source_fingerprints: :class:`dict` of :class:`str`, :class:`str`
    :ivar source_fingerprints: Map of SourceId to checksums

    :type namespace_info: :class:`dict` of :class:`list` of :class:`tuple`,
        :class:`com.vmware.vapi.metadata.cli.namespace.Info`
    :ivar namespace_info: Map of namespace id to namespace Info

    :type command_info: :class:`dict` of :class:`list` of :class:`tuple`,
        :class:`com.vmware.vapi.metadata.cli.command.Info`
    :ivar command_info: Map of command id to command Info
    """
    def __init__(self):
        # Fingerprint of all the metadata on the server
        self.fingerprint = None

        # Set of sources (file/remote)
        self.sources = {}

        # This map is used to pre-compute
        # the checksum
        self.source_fingerprints = {}

        self.namespace_fingerprint = None
        self.command_fingerprint = None

        # These 2 maps are used to keep track of key to
        # list of tuple of source id and value
        self.namespace_info = {}
        self.command_info = {}

    def update_fingerprint(self):
        """
        Update fingerprint for vAPI service metadata
        """
        ns_data = self.namespace_info.__repr__()
        cmd_data = self.command_info.__repr__()
        data = '%s%s' % (ns_data, cmd_data)
        self.fingerprint = generate_fingerprint(data)
        self.namespace_fingerprint = generate_fingerprint(ns_data)
        self.command_fingerprint = generate_fingerprint(cmd_data)

    def remove(self, id_):
        """
        Remove metadata for a vAPI service

        :type  id_: :class:`str`
        :kwarg id_: Metadata source id
        """
        if id_ not in self.sources:
            return
        del self.sources[id_]

        if id_ in self.source_fingerprints:
            del self.source_fingerprints[id_]

        namespaces_to_delete = []
        for key, items in six.iteritems(self.namespace_info):
            ns_info = [(src, val) for src, val in items if src != id_]
            if not ns_info:
                namespaces_to_delete.append(key)
            else:
                self.namespace_info[key] = ns_info
        for key in namespaces_to_delete:
            del self.namespace_info[key]

        commands_to_delete = []
        for key, items in six.iteritems(self.command_info):
            cmd_info = [(src, val) for src, val in items if src != id_]
            if not cmd_info:
                commands_to_delete.append(key)
            else:
                self.command_info[key] = cmd_info
        for key in commands_to_delete:
            del self.command_info[key]


def get_metamodel_maps():
    """
    Returns the metamodel maps

    :rtype: :class:`com.vmware.vapi.metadata.util.MetadataMaps`
    :return: Metamodel maps
    """
    return MetaModelMaps()


def get_cli_maps():
    """
    Returns the CLI maps

    :rtype: :class:`com.vmware.vapi.metadata.util.CliMaps`
    :return: Cli maps
    """
    return CliMaps()


def get_privilege_maps():
    """
    Returns the Privilege maps

    :rtype: :class:`com.vmware.vapi.metadata.util.PrivilegeMaps`
    :return: Privilege maps
    """
    return PrivilegeMaps()


def get_routing_maps():
    """
    Returns the Routing maps

    :rtype: :class:`com.vmware.vapi.metadata.util.RoutingMaps`
    :return: Routing maps
    """

    return RoutingMaps()


def get_authentication_maps():
    """
    Returns the Authentication maps

    :rtype: :class:`com.vmware.vapi.metadata.util.AuthenticationMaps`
    :return: Privilege maps
    """
    return AuthenticationMaps()
